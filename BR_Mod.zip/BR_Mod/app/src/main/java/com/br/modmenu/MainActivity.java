package com.br.modmenu;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 150, 50, 50);
        layout.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("Black Russia\nMOD MENU v4.2");
        title.setTextSize(28);
        title.setGravity(android.view.Gravity.CENTER);
        layout.addView(title);
        Button btn = new Button(this);
        btn.setText("Активировать мод");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        layout.addView(btn);
        setContentView(layout);
    }
}
